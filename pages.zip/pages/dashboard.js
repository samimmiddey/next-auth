import React from 'react';
import Dashboard from '../src/components/DashboardComponents/Dashboard';

const dashboard = () => {
    return (
        <>
            <Dashboard />
        </>
    );
};

export default dashboard;